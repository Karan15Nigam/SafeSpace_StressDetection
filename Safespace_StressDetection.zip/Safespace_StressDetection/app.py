import gradio as gr
import torch
import numpy as np
import joblib
from PIL import Image
from torchvision import transforms
from transformers import ViTImageProcessor, ViTModel
import mediapipe as mp
import json
import warnings
from microexpression import track_microexpressions
import cv2
warnings.filterwarnings("ignore", category=UserWarning, module="google.protobuf")

# ---- Simple ELM Classifier Definition (required for joblib.load to work) ----
import numpy as np
from sklearn.base import BaseEstimator, ClassifierMixin
from scipy.special import expit

class SimpleELMClassifier(BaseEstimator, ClassifierMixin):
    def __init__(self, n_hidden=4096, activation_func="relu", random_state=None):
        self.n_hidden = n_hidden
        self.activation_func = activation_func
        self.random_state = random_state

    def _activation(self, X):
        if self.activation_func == "relu":
            return np.maximum(0, X)
        elif self.activation_func == "sigmoid":
            return expit(X)
        elif self.activation_func == "tanh":
            return np.tanh(X)
        elif self.activation_func == "sine":
            return np.sin(X)
        else:
            raise ValueError("Unknown activation: %s" % self.activation_func)

    def fit(self, X, y):
        rng = np.random.RandomState(self.random_state)
        self.classes_ = np.unique(y)
        n_features = X.shape[1]
        n_classes = len(self.classes_)
        self.W = rng.normal(size=(self.n_hidden, n_features))
        self.b = rng.normal(size=(self.n_hidden,))
        H = self._activation(X @ self.W.T + self.b)
        T = np.zeros((X.shape[0], n_classes))
        for idx, label in enumerate(self.classes_):
            T[:, idx] = (y == label).astype(float)
        reg = 1e-6
        self.beta = np.linalg.pinv(H.T @ H + reg * np.eye(self.n_hidden)) @ H.T @ T
        return self

    def predict(self, X):
        H = self._activation(X @ self.W.T + self.b)
        output = H @ self.beta
        return self.classes_[np.argmax(output, axis=1)]


with open("calibration_ref.json", "r") as f:
    calibration_ref = json.load(f)

emotion_le = joblib.load("label_encoder_fer2013plus_vit.joblib")
scaler = joblib.load("scaler_fer2013plus_vit.joblib")
elm = joblib.load("elm_fer2013plus_vit.joblib")

vit_processor = ViTImageProcessor.from_pretrained('google/vit-base-patch16-224-in21k')
vit = ViTModel.from_pretrained('google/vit-base-patch16-224-in21k')
vit.eval()

vit_transforms = transforms.Compose([transforms.Resize((224, 224))])

mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(
    static_image_mode=True,
    max_num_faces=1,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

def analyze_image(image):
    # Convert to BGR OpenCV for microexpression tracker
    image_np = np.array(image.convert("RGB"))[..., ::-1].copy()
    micro_dict, bbox, _ = track_microexpressions(image_np, face_mesh, calibration_ref)
    # Crop for emotion (use bbox if present, else full image)
    h, w, _ = image_np.shape
    if bbox:
        x1 = max(0, bbox[0])
        y1 = max(0, bbox[1])
        x2 = min(w, bbox[2])
        y2 = min(h, bbox[3])
        face_img = image_np[y1:y2, x1:x2]
        if face_img is None or face_img.size == 0 or (y2 - y1 < 10 or x2 - x1 < 10):
            face_img = image_np
    else:
        face_img = image_np
    # To PIL for emotion pipeline
    face_pil = Image.fromarray(cv2.cvtColor(face_img, cv2.COLOR_BGR2RGB))
    vit_img = vit_transforms(face_pil)
    vit_inputs = vit_processor(images=vit_img, return_tensors="pt")
    with torch.no_grad():
        vit_feat = vit(**vit_inputs).last_hidden_state[:, 0, :].cpu().numpy()
    features_scaled = scaler.transform(vit_feat)
    H = elm._activation(features_scaled @ elm.W.T + elm.b)
    output = H @ elm.beta
    exp_output = np.exp(output - np.max(output, axis=1, keepdims=True))
    probs = exp_output / np.sum(exp_output, axis=1, keepdims=True)
    probs = probs.flatten()
    emotion_probs = {emotion_le.classes_[idx]: float(probs[idx]) for idx in range(len(probs))}
    # Format microexpressions as plain text
    micro_str = f"Eye Away: {micro_dict['eye_away']} | Head Turn: {micro_dict['head_turn']}"
    return emotion_probs, micro_str

iface = gr.Interface(
    fn=analyze_image,
    inputs=gr.Image(type="pil", label="Face Image (webcam or upload)"),
    outputs=[
        gr.Label(num_top_classes=len(emotion_le.classes_)),
        gr.Textbox(label="Microexpressions")
    ],
    live=False,
    title="Facial Emotion + Microexpression Analyzer",
    description="Upload a face image or use your webcam to get emotion probabilities (FER2013+) and real-time microexpression tracking.",
    allow_flagging="never"
)

if __name__ == "__main__":
    iface.launch()
